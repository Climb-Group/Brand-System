# Assist prompts

## Reply to an email in our voice

Writes a reply to an email in the ClimbUK voice, answering every question in it with one clear next step.

Display prompt: Help me reply to this email in the ClimbUK voice

Placeholders: `{{email}}`, `{{my_points}}`

```text
Help me reply to this email: {{email}}

What I want to say: {{my_points}}

Write a reply in the ClimbUK voice, UK English. Answer every question the sender asked, in their order, answer first. Keep it short: three short paragraphs at most. End with one clear next step. Do not promise anything I have not said (numbers of meetings, introductions, discounts, reports). Mark any fact you are unsure of with [CHECK]. Do not send it; show it to me first.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.
```

## Help me write a hard message

Helps write a message that says no, delivers bad news or resets expectations, kindly and clearly.

Display prompt: Help me write a hard message kindly and clearly

Placeholders: `{{recipient}}`, `{{situation}}`

```text
Help me write a difficult message to {{recipient}} about {{situation}}.

Write it in the ClimbUK voice: warm, direct, no hedging and no defensive wording. Say the decision or news in the first two sentences, give the reason in one sentence, then what happens next or what we can offer instead. No apology loops, no blame. Give me two versions: one short (under 80 words) and one fuller (under 180 words). Do not send anything.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.
```

## Coach me on a partner pitch

Plays a sceptical partner, asks the hard questions about a pitch and helps tighten the answers.

Display prompt: Coach me on my partner pitch

Placeholders: `{{company}}`, `{{pitch}}`

```text
Coach me on my ClimbUK partner pitch to {{company}}. Here is my pitch or notes: {{pitch}}

1. Play a sceptical marketing director at {{company}}. Ask me the five hardest questions they would ask, one at a time, and wait for my answer each time.
2. After each answer, tell me what landed, what did not, and a sharper way to say it in the ClimbUK voice.
3. At the end, give me a 30-second version of the pitch and the one question I should ask them.

Keep it honest: partners are sold meetings with the right people and moments on the day, never audience numbers, guaranteed leads or reports.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.
```

## Make this clear for everyone

Rewrites text in plain English at reading grade 9 or below, with clear links and abbreviations spelled out.

Display prompt: Rewrite this so everyone can understand it

Placeholders: `{{text}}`

```text
Rewrite this text so everyone can understand it, following the ClimbUK "clear for everyone" rules:

{{text}}

1. Aim for a reading grade of 9 or lower: short sentences, everyday words, one idea per sentence.
2. Spell out abbreviations on first use, short form in brackets (UK, CPD, AI, SME, FAQ and similar can stay).
3. Make link text say where it goes; never "click here", "read more" or "learn more".
4. List any jargon a newcomer might not know and suggest a glossary link or a short explanation.

Keep the meaning, the facts and the ClimbUK voice. Then give the estimated reading grade before and after.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.
```
