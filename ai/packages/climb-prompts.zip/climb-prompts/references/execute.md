# Execute prompts

## Set up a tracker

Designs a tracker (Excel table or list) for partners, speakers or stands, and builds it once you approve the columns.

Display prompt: Set up a tracker for partners, speakers or stands

Placeholders: `{{what_to_track}}`, `{{format}}`, `{{source}}`

```text
Set up a tracker for {{what_to_track}}.

1. Propose the columns, with type (text, choice, date, person, number) and the allowed values for each choice column.
2. Suggest three useful views or filters (for example: due this week, waiting on us, by owner).
3. After I approve, create it as {{format}} (an Excel table or a Microsoft List) and add any rows from {{source}}.

Keep personal data to what the task needs.
```

## Run a launch checklist

Builds a launch checklist for a campaign or ticket release and works through it step by step with you.

Display prompt: Build and run a launch checklist with me

Placeholders: `{{launch}}`, `{{date}}`

```text
Build a launch checklist for {{launch}} going live on {{date}}.

Cover: copy checked against the ClimbUK voice, links tested with UTM tags, images with alt text, contrast checked, the website page live and answering every question the launch raises, the ClimbGroup Event App updated, email and social scheduled, partners told, a person on hand for replies.

Then work through it with me one item at a time: ask whether it is done, help me do the next one, and keep a running list of what is left.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.
```

## Send meeting follow-ups

Writes a follow-up email for each attendee of a meeting with their actions, and sends them once you approve.

Display prompt: Write the follow-ups from my last meeting

Placeholders: `{{meeting}}`

```text
Use the recap and transcript of my meeting "{{meeting}}".

1. Write one short follow-up email in the ClimbUK voice to the attendees: thanks in one line, decisions, each person's actions with dates, and the next step.
2. Write a separate message to anyone with an action who was not in the meeting.
3. Show me everything first. Send only after I say yes, and tell me what was sent.

Do not include anything said in the meeting that was marked private or off the record.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.
```

## Turn notes into tasks

Turns meeting notes or a brief into tasks with owners and dates, then adds them to your task list once you confirm.

Display prompt: Turn these notes into tasks with owners and due dates

Placeholders: `{{notes}}`, `{{task_list}}`

```text
Turn these notes into tasks: {{notes}}

1. List each task with a short verb-first title, an owner, a due date and the source line it came from.
2. Flag tasks with no clear owner or date and ask me about them.
3. Once I confirm the list, add the tasks to {{task_list}} (Planner, To Do or Loop) and tell me what you added.

Do not add or assign anything before I confirm.
```
