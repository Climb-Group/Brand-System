# Analyze prompts

## Analyse a campaign's results

Turns campaign and channel results into a short readout: what worked, what did not, and what to change next.

Display prompt: Analyse the results of a campaign and tell me what to change next

Placeholders: `{{campaign}}`, `{{results}}`

```text
Analyse the results of the ClimbUK campaign "{{campaign}}" using {{results}}.

1. One-paragraph summary: did it move people to the next step (ticket, partner call, sign-up)?
2. A table by channel: reach, clicks, click rate, conversions, cost per conversion where known.
3. The best and worst performing piece of creative, and why you think so (headline, image, call to action, timing).
4. Three changes for the next campaign, ranked by likely effect.

Every link should carry UTM tags; flag any channel without them. Work only from the results given and mark guesses with [CHECK].

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
```

## Check copy against our voice

Scores a piece of copy against the ClimbUK voice and hard rules, lists every break and gives a corrected version.

Display prompt: Check this copy against the ClimbUK voice and fix what breaks it

Placeholders: `{{copy}}`

```text
Check this copy against the ClimbUK brand voice:

{{copy}}

1. List every hard-rule break (dashes, exclamation marks, emojis, "Climb" on its own, venue hints, numbers, guarantees, promised meetings, invented scarcity, hedges, vendor names, vague link text) with the exact words and the fix.
2. Score the copy from 1 to 5 on each of the four voice lines: headline energy, doing not dreaming, curated not crowded, personal not generic. One sentence of evidence per score.
3. Give a corrected version that keeps the meaning and length.
4. Say who the copy is for. If it could be about any event, say so and suggest the specific detail that fixes it.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
```

## Find themes in attendee feedback

Groups survey or session feedback into themes with counts and short quotes, and suggests fixes for the next edition.

Display prompt: Find the main themes in this attendee feedback

Placeholders: `{{feedback}}`

```text
Analyse the attendee feedback in {{feedback}} for a ClimbUK edition.

1. Group the comments into themes (agenda, speakers, networking, the ClimbGroup Event App, food, access, value). Give each theme a count and a sentiment.
2. Quote two short, typical comments per theme, with no names or identifying details.
3. List the five most fixable problems, each with one practical change for the next edition.
4. Note anything about accessibility or safety separately, even if only one person raised it.

Do not invent comments. Keep this internal; any quote used in public needs the person's consent first.
```

## Analyse ticket sales by release

Reads a ticket sales export and shows how each release, audience and channel is selling, with what to act on next.

Display prompt: Analyse our ticket sales by release, audience and channel

Placeholders: `{{sales_file}}`

```text
You are a sales analyst for ClimbUK, a festival-style business growth event. Analyse the ticket sales data in {{sales_file}}.

1. Summarise sales by ticket release (name, price, state), by audience (founders, investors, advisers, partners, public sector, students) and by channel or UTM source.
2. Show the trend week by week and call out any release that is selling faster or slower than the one before it.
3. Name the three things the team should act on this week, each with the evidence behind it.
4. List any data quality problems you found (blank audiences, duplicate orders, missing UTM tags).

Work only from the data. Do not estimate attendance or invent figures. Mark anything you are unsure of with [CHECK]. These figures are internal: do not write them as public copy.
```
