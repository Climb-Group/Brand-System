# Design prompts

## Plan event signage

Plans a set of event signs: wayfinding, room names, stands and banners with sizes, hierarchy and readable distances.

Display prompt: Plan the signage for an area of a ClimbUK event

Placeholders: `{{area}}`

```text
Plan the event signage for {{area}} at a ClimbUK edition.

1. List every sign needed (wayfinding, room or stage names, timings, stand numbers, banners, QR points), with size and where it hangs.
2. For each: the words in the ClimbUK voice, the reading distance and the minimum letter height for it.
3. Ground and colour pairs from the brand presets, with high contrast for wayfinding.
4. Icons from the ClimbUK illustration set where they help.
5. Accessible routes and step-free information on every wayfinding sign.

Name no venue in anything that will be shared before the venue is announced.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md
```

## Write an image generator prompt

Writes a prompt for an image generator that makes on-brand backgrounds and textures in the ClimbUK style.

Display prompt: Write an image generator prompt for an on-brand background

Placeholders: `{{asset}}`, `{{size}}`

```text
Write a prompt for an image generator to make a ClimbUK {{asset}} background, {{size}}.

The prompt should describe: a dark ground in deep Dark Brown or Charcoal, soft beams and glows of warm Climb Orange light cutting across it like stage light, one motif family at low opacity (rising steps, contour rings from one point, or dots joined by fine lines), a calm area for text, and no words, logos, faces or people.

Give me the prompt, a negative prompt (no text, no logos, no mountains or sport climbing, no stock handshakes, no generic skylines), and a note on which brand colour tokens to check the result against. Real people come from ClimbUK photography, never from a generator.

Brand rules: Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md
```

## Outline an on-brand slide deck

Outlines a ClimbUK slide deck slide by slide: headline, content, visual and speaker notes.

Display prompt: Outline an on-brand ClimbUK slide deck

Placeholders: `{{topic}}`, `{{audience}}`, `{{slide_count}}`

```text
Outline a ClimbUK slide deck about {{topic}} for {{audience}}, {{slide_count}} slides.

For each slide give: the headline (uppercase, the orange word and italic word marked), what goes on it (no more than three short points), the visual (photo, illustration, outline numeral, chart) and two lines of speaker notes.

Open with a title slide, close with one clear next step. Use the ClimbUK presentation template if you can open it. Dark slides for big moments, light slides for detail. One orange call to action per slide. Every chart has a title that states the finding and a text alternative.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md
```

## Plan a social graphic

Plans an on-brand social graphic: size, ground, headline, devices, photo, logo placement and alt text.

Display prompt: Plan an on-brand ClimbUK social graphic

Placeholders: `{{channel}}`, `{{message}}`

```text
Plan a ClimbUK social graphic for {{channel}} about {{message}}.

Give me:
1. The size and safe zone for that channel.
2. The ground preset (Dark Brown by default) and the colour pairs to use.
3. The headline in uppercase with the orange word and the italic word marked, plus a short line under it. Never more than two sizes of display type.
4. One motif family (Ascent, Contours, Stage Light, Connections or the highlight bar) and where it sits.
5. Photo direction: real ClimbUK attendees under stage light, text only on a solid ground or a fade that covers at most a third, nothing over faces.
6. Logo version and placement, with clear space of a large C on every edge.
7. Alt text for the finished graphic.

Do not invent colour values or logo files: name them from the brand pack.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md
```
