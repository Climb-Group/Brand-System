# Ask prompts

## Ask the ClimbUK brand guide

Answers a question about the ClimbUK brand rules (voice, logos, colours, photos) from the public brand pack.

Display prompt: What does the ClimbUK brand say about this?

Placeholders: `{{question}}`

```text
Answer this question about the ClimbUK brand: {{question}}

Answer in two or three sentences first, then give the rule and where it comes from (voice skill, visual style skill, logo guide or tokens). If the brand pack does not cover it, say so plainly and suggest the closest rule. Do not make up colour values, logo files or rules.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission. Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. Ship editable sources with every finished file: its words in a Markdown copy file with each part marked (`<!-- @front.headline -->`), and for artwork a layered SVG with live text, grouped by row and block and named after the copy file sections. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md
```

## Explain a term for the glossary

Explains a business or event term in plain words, ready to add to the ClimbUK website glossary.

Display prompt: Explain a term in plain words for the ClimbUK glossary

Placeholders: `{{term}}`

```text
Explain the term "{{term}}" for the ClimbUK website glossary.

Give: the term as it should be written, an anchor in the form term-<slug>, and one or two plain sentences (grade 9 reading level or lower) that a newcomer to growing a business would understand. Write it in the ClimbUK voice: useful, direct, no jargon inside the definition. If the term has a common abbreviation, spell it out first and give the short form in brackets.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.
```

## Answer a partner's question

Writes a clear, on-brand answer to a question from a current or possible partner, answer first.

Display prompt: Help me answer this question from a partner

Placeholders: `{{partner_question}}`, `{{context}}`

```text
A partner or possible partner asked: {{partner_question}}

Context I have: {{context}}

Write an answer in the ClimbUK voice. Open with the answer in one sentence, then the reason, then one next step ("Book a call with the team" or similar). Sell meetings with the right people, never a number of meetings, an audience size or a report we have not agreed. If I have not given you a fact the answer needs, write [CHECK: what is missing] instead of guessing.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.
```

## Ask who a message is for

Works out which ClimbUK audience a message should speak to and what that audience needs to hear.

Display prompt: Who should this message be for, and what do they need to hear?

Placeholders: `{{message_idea}}`

```text
I want to send this message: {{message_idea}}

Tell me which ClimbUK audience it should speak to (founders of growing businesses, investors, advisers, professional services firms, fractional leaders, partners, public sector, students and graduates). For that audience, give:

1. What they want from ClimbUK, in one line.
2. The one benefit to lead with.
3. The next step to ask for.
4. A headline and a one-sentence opening in the ClimbUK voice.

If the message tries to speak to everyone, say so and suggest how to split it.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.
```
