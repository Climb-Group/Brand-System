# Prepare prompts

## Prepare for a partner meeting

Builds a one-page brief for a partner meeting: who they are, what they want, history with us and what to ask.

Display prompt: Prepare me for a partner meeting

Placeholders: `{{company}}`, `{{date}}`

```text
Prepare me for my meeting with {{company}} on {{date}}.

Use my emails, chats and files about them, plus public information. Give me a one-page brief:
1. Who they are and what they sell, in three lines.
2. Our history with them and anything open.
3. What they probably want from ClimbUK and which audience they want to reach.
4. Three partnership ideas that fit, sold as meetings with the right people and moments on the day.
5. Five questions to ask.
6. The one next step to aim for.

Link sources and mark anything unconfirmed with [CHECK].

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.
```

## Prepare for a press interview

Prepares key messages, likely questions and safe answers for a press or podcast interview about ClimbUK.

Display prompt: Prepare me for a press or podcast interview

Placeholders: `{{outlet}}`, `{{topic}}`

```text
Prepare me for an interview with {{outlet}} about {{topic}}.

Give me: three key messages in the ClimbUK voice; the ten questions they are most likely to ask, with a short answer for each that leads with the point; three hard questions (numbers, venue, comparisons with other events, investment promises) with a calm answer that stays within what ClimbUK says publicly; and one line to end on. Do not invent figures.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.
```

## Prepare an event run sheet

Builds a minute-by-minute run sheet for a session, stage or event day with owners, cues and backup plans.

Display prompt: Prepare a run sheet for a session or event day

Placeholders: `{{session_or_day}}`

```text
Prepare a run sheet for {{session_or_day}}.

As a table: time, duration, what happens, who leads, AV and lighting cues, music, what is on screen, and notes. Add a contacts block (placeholders), a backup plan for the three most likely problems (speaker late, tech failure, overrun), and accessibility notes (captions, interpreters, step-free access, quiet room). Flag any timing that looks too tight.
```

## Prepare a speaker briefing

Writes the briefing a speaker needs: session details, audience, timings, tech, brand dos and don'ts and contacts.

Display prompt: Prepare a briefing pack for a speaker

Placeholders: `{{speaker}}`, `{{session}}`

```text
Prepare a briefing for {{speaker}} speaking on {{session}}.

Include: the session format, length and time; who is in the room and what they want to take away; the run of the session minute by minute; tech and slides (ClimbUK slide template, 16:9, captions); accessibility asks (describe visuals out loud, plain words); brand notes (no promises of investment or meetings, say ClimbUK not Climb); arrival and contacts as placeholders.

Keep it to one page, friendly and clear. Name no venue if the venue is not yet announced.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission. Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. Ship editable sources with every finished file: its words in a Markdown copy file with each part marked (`<!-- @front.headline -->`), and for artwork a layered SVG with live text, grouped by row and block and named after the copy file sections. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md
```
