# Learn prompts

## Learn accessible content basics

Teaches the basics of accessible writing and design for ClimbUK content, with a quick self-check list.

Display prompt: Teach me how to make our content accessible

Placeholders: `{{my_role}}`

```text
Teach me how to make ClimbUK content accessible, for my work as {{my_role}}.

Cover in plain words: reading level, link text, abbreviations, headings, alt text, colour contrast and the brand presets, text size, captions and transcripts for video, and motion. For each, give one do and one do not from real event marketing. End with a ten-point self-check list I can use before publishing anything.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md
```

## Learn about an audience

Explains what one ClimbUK audience wants, what worries them and how to speak to them.

Display prompt: Help me understand one ClimbUK audience

Placeholders: `{{audience}}`

```text
Help me understand {{audience}} as a ClimbUK audience.

Explain: who they are, what they want from ClimbUK, what worries them, the words they use and the words to avoid, who they want to find in the room, the ticket or offer that fits them, and the next step to ask for. Finish with three example headlines for them in the ClimbUK voice and one common mistake to avoid.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
```

## Learn the ClimbUK brand

Teaches the ClimbUK brand in ten minutes with a short quiz at the end, for new starters and freelancers.

Display prompt: Teach me the ClimbUK brand in ten minutes

Placeholders: `{{my_role}}`

```text
Teach me the ClimbUK brand in about ten minutes. I am {{my_role}}.

Cover, in short sections: what ClimbUK is ("business with a party, not a party for business"), where the name comes from, the four voice lines, the hard rules, the audiences, the five visual rules, colours and grounds, logos and clear space, photography, and accessibility.

Then give me a five-question quiz, one question at a time, and tell me what I got right after each answer. Use examples that fit my role.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md
```

## Learn the Investor Ladder story

Explains where the ClimbUK name comes from and how to tell the Investor Ladder story without sport-climbing images.

Display prompt: Explain the Investor Ladder story behind the ClimbUK name

Placeholders: none

```text
Explain where the ClimbUK name comes from: the Investor Ladder, where businesses climb rung by rung to reach their next investor, and investors pass businesses up and down the ladder by need.

Then give me: a one-sentence version, a 30-second spoken version, and three ways the idea shows up in the visual style (the Ascent motif, steps and chevrons). Say how to avoid it reading as a sport climbing event.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md
```
