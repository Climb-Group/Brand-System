# Catch up prompts

## Catch up on a Teams channel

Summarises a busy Teams channel: key decisions, open questions and anything that needs your answer.

Display prompt: Summarise what happened in a Teams channel this week

Placeholders: `{{channel}}`, `{{period}}`

```text
Summarise the Teams channel {{channel}} for the past {{period}}.

Give me: key decisions, open questions with who asked them, files shared, anything waiting on me, and the mood of the conversation in one line. Group by topic, not by time. Link each point to the message. Leave out greetings and small talk.
```

## Catch up on a meeting I missed

Summarises a meeting you missed from its recap, transcript and chat: decisions, actions and what was said about you.

Display prompt: Catch me up on a meeting I missed

Placeholders: `{{meeting}}`

```text
I missed the meeting "{{meeting}}". Use its recap, transcript, chat and any shared files.

1. The purpose of the meeting and the outcome, in two sentences.
2. Decisions made.
3. Actions, each with an owner and a due date if one was set.
4. Anything said about me, my team or my work.
5. Questions I should follow up on.

Only use what is in the meeting record. Mark anything unclear with [CHECK].
```

## Catch up on a partner

Summarises recent emails, chats, meetings and files with one partner company so you are up to speed in minutes.

Display prompt: Catch me up on everything with a partner from the last month

Placeholders: `{{company}}`

```text
Catch me up on {{company}}. Look at my emails, Teams chats, meetings and shared files from the last 30 days that mention them or their people.

1. Where things stand, in three sentences.
2. Decisions made and by whom, with dates.
3. Open questions and anything they are waiting on from us.
4. Upcoming meetings or deadlines.
5. The next thing I should do.

Link each point to its source. Work only from what you find; if something is unclear, say so instead of guessing.
```

## Catch me up after time off

Pulls together what happened while you were away: decisions, mentions, asks and what needs you first.

Display prompt: Catch me up on what I missed while I was away

Placeholders: `{{date}}`

```text
I have been away since {{date}}. Catch me up from my email, Teams chats, channels and meetings.

1. The five things that need me first, with who is waiting and since when.
2. Decisions made while I was away that affect my work.
3. Places I was @mentioned or asked a question that is still open.
4. Changes to dates, budgets or plans for the next ClimbUK edition.
5. Things I can safely ignore.

Keep it short and link every item to its source.
```
