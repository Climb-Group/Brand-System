# Understand prompts

## Understand design feedback

Turns scattered comments on a design into a clear list of changes, grouped and checked against the brand rules.

Display prompt: Help me make sense of the feedback on a design

Placeholders: `{{design}}`, `{{feedback}}`

```text
Help me make sense of this feedback on {{design}}: {{feedback}}

1. Group the comments into clear changes, merging duplicates.
2. Mark where comments disagree and suggest how to settle it.
3. Check each change against the ClimbUK visual style (grounds and pairs, one orange call to action, type rules, photo rules, logo clear space) and flag any that would break it.
4. Give an ordered to-do list, most important first.

Brand rules: Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md
```

## Explain a long document

Explains a long report, brief or policy in plain words: the point, the key facts and what it means for you.

Display prompt: Explain this document and what it means for my work

Placeholders: `{{document}}`, `{{my_role}}`

```text
Explain {{document}} for me as {{my_role}}.

1. The main point in two sentences.
2. The key facts, figures and dates.
3. What it means for my work and for ClimbUK.
4. Anything I need to do, and by when.
5. Terms I may not know, explained.

Quote the page or section for each point. Mark anything you are unsure of with [CHECK].
```

## Understand a partner contract

Explains a partner or supplier agreement in plain words: what we give, what we get, dates, costs and risks.

Display prompt: Help me understand this partner agreement

Placeholders: `{{document}}`

```text
Help me understand this agreement: {{document}}

Explain in plain words: who the parties are, what each side gives and gets, the money and when it is paid, key dates and notice periods, cancellation and refund terms, use of logos and names, data and privacy terms, and anything unusual or one-sided. Quote the clause for each point. Finish with questions to ask before signing.

This is a summary to help me read it, not legal advice.
```

## Understand a sector

Explains a sector (for example health or creative) for ClimbUK work: who is in it, what they need and how to speak to them.

Display prompt: Help me understand a sector for my ClimbUK work

Placeholders: `{{sector}}`, `{{region}}`

```text
Help me understand the {{sector}} sector {{region}} for my ClimbUK work.

Explain: the kinds of growing businesses in it, what holds them back, the investors, advisers and support bodies active in it, the words they use, recent public news, and why they would come to ClimbUK. Then suggest how to write for them: what to lead with and three example headlines in the ClimbUK voice. Write for the audience with the sector's people and examples. Link public sources.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
```
