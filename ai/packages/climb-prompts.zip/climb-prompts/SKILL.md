---
name: climb-prompts
description: "The ClimbUK prompt library: 56 house prompts for ClimbUK, ClimbGroup and Climb27 work, one set per task type (analyse, ask, assist, catch up, code, create, design, edit, execute, find, learn, prepare, schedule, understand). Use it when someone asks for help with a ClimbUK marketing, sales, partnership, events or design task, asks which prompts exist, or wants a ready-made prompt to start from. Pair it with climb-voice for words and climb-visual-style for anything visual."
license: Proprietary
metadata:
  owner: ClimbGroup marketing
  version: "1.0.0"
---

# ClimbUK prompt library

Generated from the brand pack. Each prompt is a tested starting point for one ClimbUK job.

## How to use it

1. Match the request to a task type and a prompt in the table below.
2. Open `references/<task type>.md` and read that prompt in full.
3. Fill each `{{placeholder}}` from what the person already said; ask for anything still missing, in one message.
4. Do the work the prompt describes, following its brand rules. Load climb-voice for any words and climb-visual-style for anything visual when they are available.
5. Say which prompt you used, so the person can find it again.

If nothing fits, follow the closest prompt's shape: the task, the inputs, a numbered output and the brand rules.

## Prompts

| Task type | Prompt | What it does | Reference |
| --- | --- | --- | --- |
| Analyze | Analyse a campaign's results | Turns campaign and channel results into a short readout: what worked, what did not, and what to change next. | `references/analyze.md` |
| Analyze | Check copy against our voice | Scores a piece of copy against the ClimbUK voice and hard rules, lists every break and gives a corrected version. | `references/analyze.md` |
| Analyze | Find themes in attendee feedback | Groups survey or session feedback into themes with counts and short quotes, and suggests fixes for the next edition. | `references/analyze.md` |
| Analyze | Analyse ticket sales by release | Reads a ticket sales export and shows how each release, audience and channel is selling, with what to act on next. | `references/analyze.md` |
| Ask | Ask the ClimbUK brand guide | Answers a question about the ClimbUK brand rules (voice, logos, colours, photos) from the public brand pack. | `references/ask.md` |
| Ask | Explain a term for the glossary | Explains a business or event term in plain words, ready to add to the ClimbUK website glossary. | `references/ask.md` |
| Ask | Answer a partner's question | Writes a clear, on-brand answer to a question from a current or possible partner, answer first. | `references/ask.md` |
| Ask | Ask who a message is for | Works out which ClimbUK audience a message should speak to and what that audience needs to hear. | `references/ask.md` |
| Assist | Reply to an email in our voice | Writes a reply to an email in the ClimbUK voice, answering every question in it with one clear next step. | `references/assist.md` |
| Assist | Help me write a hard message | Helps write a message that says no, delivers bad news or resets expectations, kindly and clearly. | `references/assist.md` |
| Assist | Coach me on a partner pitch | Plays a sceptical partner, asks the hard questions about a pitch and helps tighten the answers. | `references/assist.md` |
| Assist | Make this clear for everyone | Rewrites text in plain English at reading grade 9 or below, with clear links and abbreviations spelled out. | `references/assist.md` |
| Catch up | Catch up on a Teams channel | Summarises a busy Teams channel: key decisions, open questions and anything that needs your answer. | `references/catch-up.md` |
| Catch up | Catch up on a meeting I missed | Summarises a meeting you missed from its recap, transcript and chat: decisions, actions and what was said about you. | `references/catch-up.md` |
| Catch up | Catch up on a partner | Summarises recent emails, chats, meetings and files with one partner company so you are up to speed in minutes. | `references/catch-up.md` |
| Catch up | Catch me up after time off | Pulls together what happened while you were away: decisions, mentions, asks and what needs you first. | `references/catch-up.md` |
| Code | Review code for accessibility | Reviews front-end code against WCAG 2.2 and grades each problem HIGH, MEDIUM or LOW with the fix. | `references/code.md` |
| Code | Build an on-brand email template | Writes a responsive, accessible HTML email in the ClimbUK style that works in the main email apps. | `references/code.md` |
| Code | Write an Excel formula | Writes and explains an Excel formula or a short script for a sales, budget or attendee spreadsheet. | `references/code.md` |
| Code | Build an on-brand web section | Writes an accessible HTML and CSS section in the ClimbUK style using the brand tokens, ready to drop into a page. | `references/code.md` |
| Create | Write an event email | Writes a marketing email for a ClimbUK edition such as Climb27: subject lines, preheader, body and one call to action. | `references/create.md` |
| Create | Write a LinkedIn post | Writes a LinkedIn post for ClimbUK or Climb27, for one audience, with a clear next step and tagged link. | `references/create.md` |
| Create | Write a press release | Writes a press release for a ClimbUK announcement with headline, summary, body, a space for a real quote and notes to editors. | `references/create.md` |
| Create | Invite a speaker | Writes a personal invitation to a speaker or panellist that says why them, what we ask and what they get. | `references/create.md` |
| Design | Plan event signage | Plans a set of event signs: wayfinding, room names, stands and banners with sizes, hierarchy and readable distances. | `references/design.md` |
| Design | Write an image generator prompt | Writes a prompt for an image generator that makes on-brand backgrounds and textures in the ClimbUK style. | `references/design.md` |
| Design | Outline an on-brand slide deck | Outlines a ClimbUK slide deck slide by slide: headline, content, visual and speaker notes. | `references/design.md` |
| Design | Plan a social graphic | Plans an on-brand social graphic: size, ground, headline, devices, photo, logo placement and alt text. | `references/design.md` |
| Edit | Sharpen a headline | Gives stronger headline options in the ClimbUK poster style, with the orange word and the italic word marked. | `references/edit.md` |
| Edit | Make this copy on brand | Rewrites any copy into the ClimbUK voice while keeping its facts, and explains each change. | `references/edit.md` |
| Edit | Proofread in UK English | Proofreads text for UK spelling, grammar, punctuation and brand names, and lists every change. | `references/edit.md` |
| Edit | Shorten for a channel | Cuts copy down to fit a channel's limits (post, ad, SMS, banner) without losing the point or the next step. | `references/edit.md` |
| Execute | Set up a tracker | Designs a tracker (Excel table or list) for partners, speakers or stands, and builds it once you approve the columns. | `references/execute.md` |
| Execute | Run a launch checklist | Builds a launch checklist for a campaign or ticket release and works through it step by step with you. | `references/execute.md` |
| Execute | Send meeting follow-ups | Writes a follow-up email for each attendee of a meeting with their actions, and sends them once you approve. | `references/execute.md` |
| Execute | Turn notes into tasks | Turns meeting notes or a brief into tasks with owners and dates, then adds them to your task list once you confirm. | `references/execute.md` |
| Find | Find the right brand asset | Finds the right logo, icon, template or photo for a job and says which version and file to use. | `references/find.md` |
| Find | Find possible partners | Researches companies that serve a ClimbUK audience and could be good partners, from public information. | `references/find.md` |
| Find | Find what we said before | Searches your files, emails and chats for what ClimbUK has already said about a topic, so new copy stays consistent. | `references/find.md` |
| Find | Find speaker ideas | Suggests possible speakers for a session topic from public information, with why each fits the ClimbUK room. | `references/find.md` |
| Learn | Learn accessible content basics | Teaches the basics of accessible writing and design for ClimbUK content, with a quick self-check list. | `references/learn.md` |
| Learn | Learn about an audience | Explains what one ClimbUK audience wants, what worries them and how to speak to them. | `references/learn.md` |
| Learn | Learn the ClimbUK brand | Teaches the ClimbUK brand in ten minutes with a short quiz at the end, for new starters and freelancers. | `references/learn.md` |
| Learn | Learn the Investor Ladder story | Explains where the ClimbUK name comes from and how to tell the Investor Ladder story without sport-climbing images. | `references/learn.md` |
| Prepare | Prepare for a partner meeting | Builds a one-page brief for a partner meeting: who they are, what they want, history with us and what to ask. | `references/prepare.md` |
| Prepare | Prepare for a press interview | Prepares key messages, likely questions and safe answers for a press or podcast interview about ClimbUK. | `references/prepare.md` |
| Prepare | Prepare an event run sheet | Builds a minute-by-minute run sheet for a session, stage or event day with owners, cues and backup plans. | `references/prepare.md` |
| Prepare | Prepare a speaker briefing | Writes the briefing a speaker needs: session details, audience, timings, tech, brand dos and don'ts and contacts. | `references/prepare.md` |
| Schedule | Plan a campaign timeline | Works back from a launch or event date to a dated plan with every step, owner and dependency. | `references/schedule.md` |
| Schedule | Schedule a content calendar | Builds a content calendar across channels for a period or campaign, with themes, audiences and next steps. | `references/schedule.md` |
| Schedule | Find time for a meeting | Finds a time that suits everyone for a meeting across attendees' calendars and writes a short invitation with an agenda. | `references/schedule.md` |
| Schedule | Plan my week | Plans your week from your calendar, emails and tasks, with focus time for the most important ClimbUK work. | `references/schedule.md` |
| Understand | Understand design feedback | Turns scattered comments on a design into a clear list of changes, grouped and checked against the brand rules. | `references/understand.md` |
| Understand | Explain a long document | Explains a long report, brief or policy in plain words: the point, the key facts and what it means for you. | `references/understand.md` |
| Understand | Understand a partner contract | Explains a partner or supplier agreement in plain words: what we give, what we get, dates, costs and risks. | `references/understand.md` |
| Understand | Understand a sector | Explains a sector (for example health or creative) for ClimbUK work: who is in it, what they need and how to speak to them. | `references/understand.md` |
