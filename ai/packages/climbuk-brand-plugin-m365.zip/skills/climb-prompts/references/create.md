# Create prompts

## Write an event email

Writes a marketing email for a ClimbUK edition such as Climb27: subject lines, preheader, body and one call to action.

Display prompt: Write a ClimbUK marketing email with one clear next step

Placeholders: `{{offer}}`, `{{audience}}`

```text
Write a ClimbUK marketing email about {{offer}} for {{audience}}.

Give me:
1. Five subject lines under 50 characters and two preheaders.
2. The body: a headline, two or three short paragraphs, one button label and the link placeholder [LINK with UTM tags].
3. A plain-text version.

Lead with what the reader gets. If this is about a ticket release, name the release, its price and its state, and say the price goes up when it is gone; no other scarcity. Answer on the page any question the email raises. Link text says where it goes.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
```

## Write a LinkedIn post

Writes a LinkedIn post for ClimbUK or Climb27, for one audience, with a clear next step and tagged link.

Display prompt: Write a ClimbUK LinkedIn post for one audience

Placeholders: `{{topic}}`, `{{audience}}`

```text
Write a LinkedIn post for ClimbUK about {{topic}}, for {{audience}}.

1. A first line that works like a festival poster headline: short, confident, specific to this audience.
2. Three to five short lines on what the reader gets and why it matters to them now.
3. One next step with a link placeholder [LINK with UTM tags].
4. Up to three relevant hashtags.

Give three versions: one punchy (under 60 words), one story-led (under 150 words), one that leads with a real detail I give you. No emojis, no exclamation marks, no numbers I have not given you.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
```

## Write a press release

Writes a press release for a ClimbUK announcement with headline, summary, body, a space for a real quote and notes to editors.

Display prompt: Write a ClimbUK press release from the facts I give you

Placeholders: `{{news}}`, `{{facts}}`

```text
Write a press release for ClimbUK announcing {{news}}. Facts I can confirm: {{facts}}

Lead on what the news means for the wider public, not only for the people at the event. Name who outside the room benefits and how: people who could not otherwise start a business, young people, jobs, communities, the region, customers, public safety. If the effect is too narrow, the press will not print it.

Structure: a headline and a one-sentence summary that carry the public angle. A first paragraph that sets out the public problem. Then what ClimbUK or the partner does about it, in facts they publish, with who, what and when. Then one supporting paragraph. Then an empty quote slot, [Quote from a named, consenting person], with a one-line brief that steers the speaker to the wider impact. Then a closing line with one next step. Then Notes to editors with the press contact for every organisation in the story: ClimbUK marketing@climb-uk.com, ClimbGroup marketing@climb-group.com, and each partner's press contact.

Any figure comes from an official or primary source, named in the same sentence. Use only the facts given. Never invent quotes, names, numbers or venues. No superlatives, no comparisons with other events. Write it so a journalist can lift any paragraph on its own.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
```

## Invite a speaker

Writes a personal invitation to a speaker or panellist that says why them, what we ask and what they get.

Display prompt: Write a personal invitation to a speaker

Placeholders: `{{speaker}}`, `{{topic}}`, `{{why_them}}`

```text
Write an invitation from ClimbUK to {{speaker}} to speak about {{topic}}.

1. Open with why them, using something specific they have done: {{why_them}}.
2. Say what we are asking: format (talk, panel, roundtable or workshop), length and the audience in the room.
3. Say what they get: the people they will find, the stage moment, how we promote their session.
4. One next step: a reply or a short call.

Keep it under 180 words, warm and direct. Do not promise audience numbers, fees or coverage I have not stated.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
```
