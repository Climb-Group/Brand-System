# Find prompts

## Find the right brand asset

Finds the right logo, icon, template or photo for a job and says which version and file to use.

Display prompt: Find the right ClimbUK logo or asset for a job

Placeholders: `{{use}}`

```text
Find the right ClimbUK brand asset for {{use}}.

Tell me: which brand (ClimbUK, ClimbGroup or a Climb edition), which version (full logo, icon, li monogram, stacked tile, tagline lockup), which ground (transparent, on white, on Dark Brown, on Climb Orange), the file type and size to use, and the clear space and minimum size. If you can search my files or the brand pack, link the exact file. If more than one fits, say which to use and why.

Brand rules: Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. Ship editable sources with every finished file: its words in a Markdown copy file with each part marked (`<!-- @front.headline -->`), and for artwork a layered SVG with live text, grouped by row and block and named after the copy file sections. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md
```

## Find possible partners

Researches companies that serve a ClimbUK audience and could be good partners, from public information.

Display prompt: Find companies that could partner with ClimbUK

Placeholders: `{{audience}}`, `{{region}}`

```text
Find ten companies that could be good ClimbUK partners because they serve {{audience}} {{region}}.

For each: name, website, what they sell, why the ClimbUK audience matters to them, a recent public news item, and the kind of partnership that might fit (stage moment, roundtable, stand, hospitality). Use public information only and link your sources. Do not include personal contact details. Mark anything you could not confirm with [CHECK].
```

## Find what we said before

Searches your files, emails and chats for what ClimbUK has already said about a topic, so new copy stays consistent.

Display prompt: Find what we have already said about a topic

Placeholders: `{{topic}}`

```text
Search my files, emails, Teams chats and SharePoint for what ClimbUK has already said about {{topic}}.

List the best five sources, newest first, with a one-line summary and a link each. Then give the agreed wording if there is one, and point out anywhere the wording disagrees between sources. Only use what you find.
```

## Find speaker ideas

Suggests possible speakers for a session topic from public information, with why each fits the ClimbUK room.

Display prompt: Find speaker ideas for a session

Placeholders: `{{topic}}`, `{{audience}}`

```text
Suggest eight possible speakers for a ClimbUK session on {{topic}} for {{audience}}.

For each: name, role and company, what they have done that this audience would learn from, where they have spoken before, and a public link. Favour people who have grown a business and can share what they learned the expensive way. Aim for a lineup that is balanced and not all from one sector or background. Use public information only; no personal contact details.
```
