# Schedule prompts

## Plan a campaign timeline

Works back from a launch or event date to a dated plan with every step, owner and dependency.

Display prompt: Plan a campaign timeline working back from a date

Placeholders: `{{campaign}}`, `{{date}}`

```text
Plan a timeline for {{campaign}}, working back from {{date}}.

List every step (brief, copy, design, approvals, page build, email and social setup, partner sign-off, launch, follow-up) with a start date, end date, owner and what it depends on. Leave time for brand and accessibility checks and a buffer before launch. Show the critical path and the first three things to start this week.
```

## Schedule a content calendar

Builds a content calendar across channels for a period or campaign, with themes, audiences and next steps.

Display prompt: Build a content calendar leading up to a milestone

Placeholders: `{{period}}`, `{{milestone}}`

```text
Build a ClimbUK content calendar for {{period}}, leading up to {{milestone}}.

As a table: date, channel, audience, theme, headline idea in the ClimbUK voice, format (post, video, email, story), call to action and owner. Balance the audiences across the weeks. Build up energy towards the milestone, with ticket release moments named by release and state. Leave room for reacting to news. Keep posting times sensible for UK audiences.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
```

## Find time for a meeting

Finds a time that suits everyone for a meeting across attendees' calendars and writes a short invitation with an agenda.

Display prompt: Find a time that works for everyone and write the invitation

Placeholders: `{{length}}`, `{{people}}`, `{{purpose}}`, `{{window}}`

```text
Find a time for a {{length}} meeting with {{people}} about {{purpose}} in the next {{window}}.

Suggest three slots that work for everyone, avoiding early mornings, late afternoons on Fridays and back-to-back days. Then write the invitation: a clear title, a three-point agenda, what to prepare, and a Teams link. Show me before sending anything.
```

## Plan my week

Plans your week from your calendar, emails and tasks, with focus time for the most important ClimbUK work.

Display prompt: Plan my week around my most important work

Placeholders: none

```text
Plan my week. Look at my calendar, flagged emails, tasks and recent chats.

1. My top three priorities for the week and why.
2. A day-by-day plan with focus blocks for those priorities.
3. Meetings I could decline, shorten or delegate.
4. Deadlines this week and next.
5. Anyone waiting on me.

Do not change my calendar; suggest, and I will confirm.
```
