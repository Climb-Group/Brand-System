---
description: "Rewrites any copy into the ClimbUK voice while keeping its facts, and explains each change."
argument-hint: "[copy]"
---

Rewrite this copy in the ClimbUK voice:

[copy]

Keep every fact and the length roughly the same. Fix every hard-rule break. Make the opening line work like a headline, name the outcome for the reader and end with one next step. Then list each change you made and why, in one line each.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

Details from me: $ARGUMENTS

If any detail in square brackets above is missing, ask me for it before you start.
