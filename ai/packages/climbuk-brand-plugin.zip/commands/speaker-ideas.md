---
description: "Suggests possible speakers for a session topic from public information, with why each fits the ClimbUK room."
argument-hint: "[topic] [audience]"
---

Suggest eight possible speakers for a ClimbUK session on [topic] for [audience].

For each: name, role and company, what they have done that this audience would learn from, where they have spoken before, and a public link. Favour people who have grown a business and can share what they learned the expensive way. Aim for a lineup that is balanced and not all from one sector or background. Use public information only; no personal contact details.

Details from me: $ARGUMENTS

If any detail in square brackets above is missing, ask me for it before you start.
