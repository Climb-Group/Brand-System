---
description: "Finds a time that suits everyone for a meeting across attendees' calendars and writes a short invitation with an agenda."
argument-hint: "[length] [people] [purpose] [window]"
---

Find a time for a [length] meeting with [people] about [purpose] in the next [window].

Suggest three slots that work for everyone, avoiding early mornings, late afternoons on Fridays and back-to-back days. Then write the invitation: a clear title, a three-point agenda, what to prepare, and a Teams link. Show me before sending anything.

Details from me: $ARGUMENTS

If any detail in square brackets above is missing, ask me for it before you start.
