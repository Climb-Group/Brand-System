---
description: "Builds a minute-by-minute run sheet for a session, stage or event day with owners, cues and backup plans."
argument-hint: "[session or day]"
---

Prepare a run sheet for [session or day].

As a table: time, duration, what happens, who leads, AV and lighting cues, music, what is on screen, and notes. Add a contacts block (placeholders), a backup plan for the three most likely problems (speaker late, tech failure, overrun), and accessibility notes (captions, interpreters, step-free access, quiet room). Flag any timing that looks too tight.

Details from me: $ARGUMENTS

If any detail in square brackets above is missing, ask me for it before you start.
