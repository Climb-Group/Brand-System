---
description: "Works back from a launch or event date to a dated plan with every step, owner and dependency."
argument-hint: "[campaign] [date]"
---

Plan a timeline for [campaign], working back from [date].

List every step (brief, copy, design, approvals, page build, email and social setup, partner sign-off, launch, follow-up) with a start date, end date, owner and what it depends on. Leave time for brand and accessibility checks and a buffer before launch. Show the critical path and the first three things to start this week.

Details from me: $ARGUMENTS

If any detail in square brackets above is missing, ask me for it before you start.
