---
description: "Summarises a busy Teams channel: key decisions, open questions and anything that needs your answer."
argument-hint: "[channel] [period]"
---

Summarise the Teams channel [channel] for the past [period].

Give me: key decisions, open questions with who asked them, files shared, anything waiting on me, and the mood of the conversation in one line. Group by topic, not by time. Link each point to the message. Leave out greetings and small talk.

Details from me: $ARGUMENTS

If any detail in square brackets above is missing, ask me for it before you start.
