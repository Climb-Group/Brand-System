---
description: "Searches your files, emails and chats for what ClimbUK has already said about a topic, so new copy stays consistent."
argument-hint: "[topic]"
---

Search my files, emails, Teams chats and SharePoint for what ClimbUK has already said about [topic].

List the best five sources, newest first, with a one-line summary and a link each. Then give the agreed wording if there is one, and point out anywhere the wording disagrees between sources. Only use what you find.

Details from me: $ARGUMENTS

If any detail in square brackets above is missing, ask me for it before you start.
