---
description: "Builds a content calendar across channels for a period or campaign, with themes, audiences and next steps."
argument-hint: "[period] [milestone]"
---

Build a ClimbUK content calendar for [period], leading up to [milestone].

As a table: date, channel, audience, theme, headline idea in the ClimbUK voice, format (post, video, email, story), call to action and owner. Balance the audiences across the weeks. Build up energy towards the milestone, with ticket release moments named by release and state. Leave room for reacting to news. Keep posting times sensible for UK audiences.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

Details from me: $ARGUMENTS

If any detail in square brackets above is missing, ask me for it before you start.
