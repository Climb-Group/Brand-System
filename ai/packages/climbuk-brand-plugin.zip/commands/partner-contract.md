---
description: "Explains a partner or supplier agreement in plain words: what we give, what we get, dates, costs and risks."
argument-hint: "[document]"
---

Help me understand this agreement: [document]

Explain in plain words: who the parties are, what each side gives and gets, the money and when it is paid, key dates and notice periods, cancellation and refund terms, use of logos and names, data and privacy terms, and anything unusual or one-sided. Quote the clause for each point. Finish with questions to ask before signing.

This is a summary to help me read it, not legal advice.

Details from me: $ARGUMENTS

If any detail in square brackets above is missing, ask me for it before you start.
