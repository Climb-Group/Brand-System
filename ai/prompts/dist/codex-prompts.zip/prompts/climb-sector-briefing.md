---
description: "Explains a sector (for example health or creative) for ClimbUK work: who is in it, what they need and how to speak to them."
argument-hint: "SECTOR=<sector> REGION=<region>"
---

Help me understand the $SECTOR sector $REGION for my ClimbUK work.

Explain: the kinds of growing businesses in it, what holds them back, the investors, advisers and support bodies active in it, the words they use, recent public news, and why they would come to ClimbUK. Then suggest how to write for them: what to lead with and three example headlines in the ClimbUK voice. Write for the audience with the sector's people and examples. Link public sources.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
