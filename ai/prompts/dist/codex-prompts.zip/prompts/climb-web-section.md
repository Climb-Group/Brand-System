---
description: "Writes an accessible HTML and CSS section in the ClimbUK style using the brand tokens, ready to drop into a page."
argument-hint: "PURPOSE=<purpose> CONTENT=<content>"
---

Build a responsive web section for ClimbUK: $PURPOSE. Content to use: $CONTENT

Rules:
1. Plain semantic HTML and CSS. Use the ClimbUK token custom properties (var(--climb-...)) from tokens.css for every colour, size, space and radius; never type a raw colour value.
2. Dark first: Dark Brown ground unless the content is reading-heavy. One orange call to action per section, with a 19px bold white label.
3. Headline: Montserrat, uppercase, one word in Climb Orange and one in italic. Body in Open Sans.
4. WCAG 2.2 AA at least: one heading level in order, real buttons and links, visible focus, 44px targets, alt text, contrast from the brand presets, respects prefers-reduced-motion.
5. Every button in a row of cards shares one baseline (cards as flex columns, last block pushed down).

Return the HTML and CSS, then a short list of the accessibility checks you made.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md
