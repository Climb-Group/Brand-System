---
description: "Finds the right logo, icon, template or photo for a job and says which version and file to use."
argument-hint: "USE=<use>"
---

Find the right ClimbUK brand asset for $USE.

Tell me: which brand (ClimbUK, ClimbGroup or a Climb edition), which version (full logo, icon, li monogram, stacked tile, tagline lockup), which ground (transparent, on white, on Dark Brown, on Climb Orange), the file type and size to use, and the clear space and minimum size. If you can search my files or the brand pack, link the exact file. If more than one fits, say which to use and why.

Brand rules: Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md
