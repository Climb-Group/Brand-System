---
description: "Summarises a meeting you missed from its recap, transcript and chat: decisions, actions and what was said about you."
argument-hint: "MEETING=<meeting>"
---

I missed the meeting "$MEETING". Use its recap, transcript, chat and any shared files.

1. The purpose of the meeting and the outcome, in two sentences.
2. Decisions made.
3. Actions, each with an owner and a due date if one was set.
4. Anything said about me, my team or my work.
5. Questions I should follow up on.

Only use what is in the meeting record. Mark anything unclear with [CHECK].
