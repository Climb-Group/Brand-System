---
description: "Explains a long report, brief or policy in plain words: the point, the key facts and what it means for you."
argument-hint: "DOCUMENT=<document> MY_ROLE=<my role>"
---

Explain $DOCUMENT for me as $MY_ROLE.

1. The main point in two sentences.
2. The key facts, figures and dates.
3. What it means for my work and for ClimbUK.
4. Anything I need to do, and by when.
5. Terms I may not know, explained.

Quote the page or section for each point. Mark anything you are unsure of with [CHECK].
