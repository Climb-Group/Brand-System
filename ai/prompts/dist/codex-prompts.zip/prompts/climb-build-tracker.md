---
description: "Designs a tracker (Excel table or list) for partners, speakers or stands, and builds it once you approve the columns."
argument-hint: "WHAT_TO_TRACK=<what to track> FORMAT=<format> SOURCE=<source>"
---

Set up a tracker for $WHAT_TO_TRACK.

1. Propose the columns, with type (text, choice, date, person, number) and the allowed values for each choice column.
2. Suggest three useful views or filters (for example: due this week, waiting on us, by owner).
3. After I approve, create it as $FORMAT (an Excel table or a Microsoft List) and add any rows from $SOURCE.

Keep personal data to what the task needs.
