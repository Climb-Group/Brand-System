---
description: "Works out which ClimbUK audience a message should speak to and what that audience needs to hear."
argument-hint: "MESSAGE_IDEA=<message idea>"
---

I want to send this message: $MESSAGE_IDEA

Tell me which ClimbUK audience it should speak to (founders of growing businesses, investors, advisers, professional services firms, fractional leaders, partners, public sector, students and graduates). For that audience, give:

1. What they want from ClimbUK, in one line.
2. The one benefit to lead with.
3. The next step to ask for.
4. A headline and a one-sentence opening in the ClimbUK voice.

If the message tries to speak to everyone, say so and suggest how to split it.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.
