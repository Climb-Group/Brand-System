---
description: "Writes and explains an Excel formula or a short script for a sales, budget or attendee spreadsheet."
argument-hint: "GOAL=<goal> SHEET_AND_COLUMNS=<sheet and columns>"
---

Write an Excel formula that $GOAL. The data is in $SHEET_AND_COLUMNS.

1. Give the formula, using structured table references if the data is a table.
2. Explain each part in one line.
3. Give one example row and its result.
4. Note edge cases (blank cells, text in number columns, dates stored as text) and a version that handles them.
5. If a PivotTable, a LAMBDA or a short Office Script would be simpler, say so and show it.
