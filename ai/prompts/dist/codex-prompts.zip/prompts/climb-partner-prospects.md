---
description: "Researches companies that serve a ClimbUK audience and could be good partners, from public information."
argument-hint: "AUDIENCE=<audience> REGION=<region>"
---

Find ten companies that could be good ClimbUK partners because they serve $AUDIENCE $REGION.

For each: name, website, what they sell, why the ClimbUK audience matters to them, a recent public news item, and the kind of partnership that might fit (stage moment, roundtable, stand, hospitality). Use public information only and link your sources. Do not include personal contact details. Mark anything you could not confirm with [CHECK].
