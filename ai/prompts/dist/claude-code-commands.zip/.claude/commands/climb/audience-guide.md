---
description: "Explains what one ClimbUK audience wants, what worries them and how to speak to them."
argument-hint: "[audience]"
---

Help me understand [audience] as a ClimbUK audience.

Explain: who they are, what they want from ClimbUK, what worries them, the words they use and the words to avoid, who they want to find in the room, the ticket or offer that fits them, and the next step to ask for. Finish with three example headlines for them in the ClimbUK voice and one common mistake to avoid.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.

Details from me: $ARGUMENTS

If any detail in square brackets above is missing, ask me for it before you start.
