---
description: "Writes a press release for a ClimbUK announcement with headline, summary, body, a space for a real quote and notes to editors."
argument-hint: "[news] [facts] [approvals] [audience]"
---

Write a press release for ClimbUK announcing [news]. Confirmed facts and their sources: [facts]. Publication permissions, approved quotes and media/public launch times: [approvals]. Primary reader and news value: [audience].

Use a factual headline that explains the development and its benefit, not a poster slogan. Add supporting lines only for new facts. Open with who, what, when, the cleared location and why it matters. Write in third person outside quotes. Follow with the strongest evidence and practical activity, approved quotes, one relevant next step, then Notes to editors and the agreed media contact.

Explain the evidenced public or regional benefit without forcing a general social problem ahead of the news. Source external figures to the primary publisher. Keep the tone optimistic, grounded and precise. Put founder outcomes before organisational promotion. An investor story can lead when it explains a founder opportunity. Distinguish a visiting partner's contribution from established relationships. Move secondary history, biographies, product details and sales offers out of the main story unless essential to the news. Use the length the story needs, without padding or a fixed quote count.

Preserve approved quoted speech exactly. Reuse approved partner statements verbatim only within their permission. Check names, roles, figures, periods and status. Never invent quotes or publish an unsigned deal. If approval or evidence is missing, return an internal review note and an incomplete review copy, not release-ready text. Keep placeholders out of the final release. Respect the agreed embargo across press, newsletter, web and social. Use one approved master and cleared images with captions and credits.

Follow the press-specific method in the climb-voice reference channels.md. General poster headline limits and marketing testimonial layout rules do not apply. A copy check does not establish truth or permission to publish.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.

Details from me: $ARGUMENTS

If any detail in square brackets above is missing, ask me for it before you start.
