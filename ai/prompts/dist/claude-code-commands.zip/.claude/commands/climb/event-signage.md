---
description: "Plans a set of event signs: wayfinding, room names, stands and banners with sizes, hierarchy and readable distances."
argument-hint: "[area]"
---

Plan the event signage for [area] at a ClimbUK edition.

1. List every sign needed (wayfinding, room or stage names, timings, stand numbers, banners, QR points), with size and where it hangs.
2. For each: the words in the ClimbUK voice, the reading distance and the minimum letter height for it.
3. Ground and colour pairs from the brand presets, with high contrast for wayfinding.
4. Icons from the ClimbUK illustration set where they help.
5. Accessible routes and step-free information on every wayfinding sign.

Name no venue in anything that will be shared before the venue is announced.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission. Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. Ship editable sources with every finished file: its words in a Markdown copy file with each part marked (`<!-- @front.headline -->`), and for artwork a layered SVG with live text, grouped by row and block and named after the copy file sections. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md

Details from me: $ARGUMENTS

If any detail in square brackets above is missing, ask me for it before you start.
