---
description: "Writes a personal invitation to a speaker or panellist that says why them, what we ask and what they get."
argument-hint: "[speaker] [topic] [why them]"
---

Write an invitation from ClimbUK to [speaker] to speak about [topic].

1. Open with why them, using something specific they have done: [why them].
2. Say what we are asking: format (talk, panel, roundtable or workshop), length and the audience in the room.
3. Say what they get: the people they will find, the stage moment, how we promote their session.
4. One next step: a reply or a short call.

Keep it under 180 words, warm and direct. Do not promise audience numbers, fees or coverage I have not stated.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.

Details from me: $ARGUMENTS

If any detail in square brackets above is missing, ask me for it before you start.
