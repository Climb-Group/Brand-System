---
description: "Explains a business or event term in plain words, ready to add to the ClimbUK website glossary."
---

Explain the term "${input:term:term}" for the ClimbUK website glossary.

Give: the term as it should be written, an anchor in the form term-<slug>, and one or two plain sentences (grade 9 reading level or lower) that a newcomer to growing a business would understand. Write it in the ClimbUK voice: useful, direct, no jargon inside the definition. If the term has a common abbreviation, spell it out first and give the short form in brackets.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
