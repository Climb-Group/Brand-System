---
description: "Works back from a launch or event date to a dated plan with every step, owner and dependency."
---

Plan a timeline for ${input:campaign:campaign}, working back from ${input:date:date}.

List every step (brief, copy, design, approvals, page build, email and social setup, partner sign-off, launch, follow-up) with a start date, end date, owner and what it depends on. Leave time for brand and accessibility checks and a buffer before launch. Show the critical path and the first three things to start this week.
