---
description: "Builds a minute-by-minute run sheet for a session, stage or event day with owners, cues and backup plans."
---

Prepare a run sheet for ${input:session_or_day:session or day}.

As a table: time, duration, what happens, who leads, AV and lighting cues, music, what is on screen, and notes. Add a contacts block (placeholders), a backup plan for the three most likely problems (speaker late, tech failure, overrun), and accessibility notes (captions, interpreters, step-free access, quiet room). Flag any timing that looks too tight.
