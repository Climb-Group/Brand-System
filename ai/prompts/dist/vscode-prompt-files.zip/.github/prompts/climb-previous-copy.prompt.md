---
description: "Searches your files, emails and chats for what ClimbUK has already said about a topic, so new copy stays consistent."
---

Search my files, emails, Teams chats and SharePoint for what ClimbUK has already said about ${input:topic:topic}.

List the best five sources, newest first, with a one-line summary and a link each. Then give the agreed wording if there is one, and point out anywhere the wording disagrees between sources. Only use what you find.
