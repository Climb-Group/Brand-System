---
description: "Writes a personal invitation to a speaker or panellist that says why them, what we ask and what they get."
---

Write an invitation from ClimbUK to ${input:speaker:speaker} to speak about ${input:topic:topic}.

1. Open with why them, using something specific they have done: ${input:why_them:why them}.
2. Say what we are asking: format (talk, panel, roundtable or workshop), length and the audience in the room.
3. Say what they get: the people they will find, the stage moment, how we promote their session.
4. One next step: a reply or a short call.

Keep it under 180 words, warm and direct. Do not promise audience numbers, fees or coverage I have not stated.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
