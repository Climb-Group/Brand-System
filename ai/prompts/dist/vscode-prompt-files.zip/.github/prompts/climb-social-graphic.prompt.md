---
description: "Plans an on-brand social graphic: size, ground, headline, devices, photo, logo placement and alt text."
---

Plan a ClimbUK social graphic for ${input:channel:channel} about ${input:message:message}.

Give me:
1. The size and safe zone for that channel.
2. The ground preset (Dark Brown by default) and the colour pairs to use.
3. The headline in uppercase with the orange word and the italic word marked, plus a short line under it. Never more than two sizes of display type.
4. One motif family (Ascent, Contours, Stage Light, Connections or the highlight bar) and where it sits.
5. Photo direction: real ClimbUK attendees under stage light, text only on a solid ground or a fade that covers at most a third, nothing over faces.
6. Logo version and placement, with clear space of a large C on every edge.
7. Alt text for the finished graphic.

Do not invent colour values or logo files: name them from the brand pack.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md
