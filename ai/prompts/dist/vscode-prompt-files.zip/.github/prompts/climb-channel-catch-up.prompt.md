---
description: "Summarises a busy Teams channel: key decisions, open questions and anything that needs your answer."
---

Summarise the Teams channel ${input:channel:channel} for the past ${input:period:period}.

Give me: key decisions, open questions with who asked them, files shared, anything waiting on me, and the mood of the conversation in one line. Group by topic, not by time. Link each point to the message. Leave out greetings and small talk.
