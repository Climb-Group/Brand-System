---
description: "Turns campaign and channel results into a short readout: what worked, what did not, and what to change next."
---

Analyse the results of the ClimbUK campaign "${input:campaign:campaign}" using ${input:results:results}.

1. One-paragraph summary: did it move people to the next step (ticket, partner call, sign-up)?
2. A table by channel: reach, clicks, click rate, conversions, cost per conversion where known.
3. The best and worst performing piece of creative, and why you think so (headline, image, call to action, timing).
4. Three changes for the next campaign, ranked by likely effect.

Every link should carry UTM tags; flag any channel without them. Work only from the results given and mark guesses with [CHECK].

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
