---
description: "Reviews front-end code against WCAG 2.2 and grades each problem HIGH, MEDIUM or LOW with the fix."
---

Review this front-end code for accessibility against WCAG 2.2 AA (and AAA where it is small and easy):

${input:code:code}

For each problem give: severity (HIGH, MEDIUM or LOW), the WCAG success criterion, the line or element, what goes wrong for a real user, and the fixed code. Check headings, landmarks, labels and accessible names, keyboard use and focus, contrast against the ClimbUK presets, target size, motion, zoom and reflow. One row per root cause. End with Block or Approve and one sentence why.

Brand rules: Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md
