---
description: "Writes a press release for a ClimbUK announcement with headline, summary, body, a space for a real quote and notes to editors."
---

Write a press release for ClimbUK announcing ${input:news:news}. Facts I can confirm: ${input:facts:facts}

Structure: headline, one-sentence summary, a first paragraph that answers who, what, when and why, two supporting paragraphs, a quote placeholder [QUOTE from a named, consenting person], a closing line with one next step, then Notes to editors with the press contact marketing@climb-uk.com.

Use only the facts given. Never invent quotes, names, numbers or venues. No superlatives, no comparisons with other events. Write it so a journalist can lift any paragraph on its own.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
