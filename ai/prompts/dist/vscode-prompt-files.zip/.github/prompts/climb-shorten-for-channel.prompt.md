---
description: "Cuts copy down to fit a channel's limits (post, ad, SMS, banner) without losing the point or the next step."
---

Shorten this copy for ${input:channel:channel}:

${input:copy:copy}

Fit the channel's length and shape. Keep the one most important benefit and the next step. Give three versions at different lengths, with the character count for each. Stay in the ClimbUK voice and keep any facts exactly as given.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
