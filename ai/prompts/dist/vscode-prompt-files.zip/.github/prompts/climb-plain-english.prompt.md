---
description: "Rewrites text in plain English at reading grade 9 or below, with clear links and abbreviations spelled out."
---

Rewrite this text so everyone can understand it, following the ClimbUK "clear for everyone" rules:

${input:text:text}

1. Aim for a reading grade of 9 or lower: short sentences, everyday words, one idea per sentence.
2. Spell out abbreviations on first use, short form in brackets (UK, CPD, AI, SME, FAQ and similar can stay).
3. Make link text say where it goes; never "click here", "read more" or "learn more".
4. List any jargon a newcomer might not know and suggest a glossary link or a short explanation.

Keep the meaning, the facts and the ClimbUK voice. Then give the estimated reading grade before and after.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.
