---
description: "Pulls together what happened while you were away: decisions, mentions, asks and what needs you first."
---

I have been away since ${input:date:date}. Catch me up from my email, Teams chats, channels and meetings.

1. The five things that need me first, with who is waiting and since when.
2. Decisions made while I was away that affect my work.
3. Places I was @mentioned or asked a question that is still open.
4. Changes to dates, budgets or plans for the next ClimbUK edition.
5. Things I can safely ignore.

Keep it short and link every item to its source.
