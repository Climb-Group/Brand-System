---
description: "Scores a piece of copy against the ClimbUK voice and hard rules, lists every break and gives a corrected version."
---

Check this copy against the ClimbUK brand voice:

${input:copy:copy}

1. List every hard-rule break (dashes, exclamation marks, emojis, "Climb" on its own, venue hints, numbers, guarantees, promised meetings, invented scarcity, hedges, vendor names, vague link text) with the exact words and the fix.
2. Score the copy from 1 to 5 on each of the four voice lines: headline energy, doing not dreaming, curated not crowded, personal not generic. One sentence of evidence per score.
3. Give a corrected version that keeps the meaning and length.
4. Say who the copy is for. If it could be about any event, say so and suggest the specific detail that fixes it.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
