---
description: "Finds a time that suits everyone for a meeting across attendees' calendars and writes a short invitation with an agenda."
---

Find a time for a ${input:length:length} meeting with ${input:people:people} about ${input:purpose:purpose} in the next ${input:window:window}.

Suggest three slots that work for everyone, avoiding early mornings, late afternoons on Fridays and back-to-back days. Then write the invitation: a clear title, a three-point agenda, what to prepare, and a Teams link. Show me before sending anything.
