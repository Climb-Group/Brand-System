---
description: "Plays a sceptical partner, asks the hard questions about a pitch and helps tighten the answers."
---

Coach me on my ClimbUK partner pitch to ${input:company:company}. Here is my pitch or notes: ${input:pitch:pitch}

1. Play a sceptical marketing director at ${input:company:company}. Ask me the five hardest questions they would ask, one at a time, and wait for my answer each time.
2. After each answer, tell me what landed, what did not, and a sharper way to say it in the ClimbUK voice.
3. At the end, give me a 30-second version of the pitch and the one question I should ask them.

Keep it honest: partners are sold meetings with the right people and moments on the day, never audience numbers, guaranteed leads or reports.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
