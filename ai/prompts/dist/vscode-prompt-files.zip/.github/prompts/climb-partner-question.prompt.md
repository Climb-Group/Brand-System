---
description: "Writes a clear, on-brand answer to a question from a current or possible partner, answer first."
---

A partner or possible partner asked: ${input:partner_question:partner question}

Context I have: ${input:context:context}

Write an answer in the ClimbUK voice. Open with the answer in one sentence, then the reason, then one next step ("Book a call with the team" or similar). Sell meetings with the right people, never a number of meetings, an audience size or a report we have not agreed. If I have not given you a fact the answer needs, write [CHECK: what is missing] instead of guessing.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
