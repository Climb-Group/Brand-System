---
description: "Writes a prompt for an image generator that makes on-brand backgrounds and textures in the ClimbUK style."
---

Write a prompt for an image generator to make a ClimbUK ${input:asset:asset} background, ${input:size:size}.

The prompt should describe: a dark ground in deep Dark Brown or Charcoal, soft beams and glows of warm Climb Orange light cutting across it like stage light, one motif family at low opacity (rising steps, contour rings from one point, or dots joined by fine lines), a calm area for text, and no words, logos, faces or people.

Give me the prompt, a negative prompt (no text, no logos, no mountains or sport climbing, no stock handshakes, no generic skylines), and a note on which brand colour tokens to check the result against. Real people come from ClimbUK photography, never from a generator.

Brand rules: Follow the ClimbUK visual style: a festival poster with a clear next step, never a corporate conference look. Dark first (Dark Brown or Charcoal grounds; White or Light Grey for reading-heavy pieces). Orange leads but does not flood: one Climb Orange call to action per view. Montserrat Bold or Black in uppercase for headlines, with one word in Climb Orange and one in italic; Open Sans for reading. Real ClimbUK photography under stage light, never stock; text only on a solid ground or a fade, never over faces. One motif family per piece (the Ascent, Contours, Stage Light, Connections or the highlight bar), from the Investor Ladder and the stage, never sport climbing or mountains. Logos keep clear space of a large C on every edge. Use only the colours and sizes in the brand tokens and their contrast presets, WCAG 2.2 AA at least. If you can load the climb-visual-style skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-visual-style/SKILL.md
