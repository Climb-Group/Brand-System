---
description: "Writes a LinkedIn post for ClimbUK or Climb27, for one audience, with a clear next step and tagged link."
---

Write a LinkedIn post for ClimbUK about ${input:topic:topic}, for ${input:audience:audience}.

1. A first line that works like a festival poster headline: short, confident, specific to this audience.
2. Three to five short lines on what the reader gets and why it matters to them now.
3. One next step with a link placeholder [LINK with UTM tags].
4. Up to three relevant hashtags.

Give three versions: one punchy (under 60 words), one story-led (under 150 words), one that leads with a real detail I give you. No emojis, no exclamation marks, no numbers I have not given you.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md
