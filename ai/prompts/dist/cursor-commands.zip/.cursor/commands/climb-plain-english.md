---
description: "Rewrites text in plain English at reading grade 9 or below, with clear links and abbreviations spelled out."
---

Rewrite this text so everyone can understand it, following the ClimbUK "clear for everyone" rules:

[text]

1. Aim for a reading grade of 9 or lower: short sentences, everyday words, one idea per sentence.
2. Spell out abbreviations on first use, short form in brackets (UK, CPD, AI, SME, FAQ and similar can stay).
3. Make link text say where it goes; never "click here", "read more" or "learn more".
4. List any jargon a newcomer might not know and suggest a glossary link or a short explanation.

Keep the meaning, the facts and the ClimbUK voice. Then give the estimated reading grade before and after.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

If any detail in square brackets above is missing, ask me for it before you start.
