---
description: "Writes a marketing email for a ClimbUK edition such as Climb27: subject lines, preheader, body and one call to action."
---

Write a ClimbUK marketing email about [offer] for [audience].

Give me:
1. Five subject lines under 50 characters and two preheaders.
2. The body: a headline, two or three short paragraphs, one button label and the link placeholder [LINK with UTM tags].
3. A plain-text version.

Lead with what the reader gets. If this is about a ticket release, name the release, its price and its state, and say the price goes up when it is gone; no other scarcity. Answer on the page any question the email raises. Link text says where it goes.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

If any detail in square brackets above is missing, ask me for it before you start.
