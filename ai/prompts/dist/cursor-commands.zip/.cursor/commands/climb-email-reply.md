---
description: "Writes a reply to an email in the ClimbUK voice, answering every question in it with one clear next step."
---

Help me reply to this email: [email]

What I want to say: [my points]

Write a reply in the ClimbUK voice, UK English. Answer every question the sender asked, in their order, answer first. Keep it short: three short paragraphs at most. End with one clear next step. Do not promise anything I have not said (numbers of meetings, introductions, discounts, reports). Mark any fact you are unsure of with [CHECK]. Do not send it; show it to me first.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

If any detail in square brackets above is missing, ask me for it before you start.
