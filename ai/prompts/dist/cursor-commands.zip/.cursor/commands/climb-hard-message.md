---
description: "Helps write a message that says no, delivers bad news or resets expectations, kindly and clearly."
---

Help me write a difficult message to [recipient] about [situation].

Write it in the ClimbUK voice: warm, direct, no hedging and no defensive wording. Say the decision or news in the first two sentences, give the reason in one sentence, then what happens next or what we can offer instead. No apology loops, no blame. Give me two versions: one short (under 80 words) and one fuller (under 180 words). Do not send anything.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

For press releases, use the press-specific method: factual headlines, third-person reporting, practical evidence and approved quotes. Poster word limits and marketing testimonial counts do not apply. Preserve approved speech and check each claim, name, role and launch permission.

If any detail in square brackets above is missing, ask me for it before you start.
