---
description: "Proofreads text for UK spelling, grammar, punctuation and brand names, and lists every change."
---

Proofread this text in UK English:

[text]

Fix spelling, grammar and punctuation. Check brand names: ClimbUK, ClimbGroup, Climb27, the ClimbGroup Event App, Affiliate Programme. Replace em and en dashes with a hyphen-minus, a comma or a full stop. Capitalise job titles. Return the corrected text, then a list of every change.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. Keep every piece's words in a Markdown copy file with each part of the design marked on its own line (`<!-- @front.headline -->`), and change words there, never only in the design. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

If any detail in square brackets above is missing, ask me for it before you start.
