---
description: "Works out which ClimbUK audience a message should speak to and what that audience needs to hear."
---

I want to send this message: [message idea]

Tell me which ClimbUK audience it should speak to (founders of growing businesses, investors, advisers, professional services firms, fractional leaders, partners, public sector, students and graduates). For that audience, give:

1. What they want from ClimbUK, in one line.
2. The one benefit to lead with.
3. The next step to ask for.
4. A headline and a one-sentence opening in the ClimbUK voice.

If the message tries to speak to everyone, say so and suggest how to split it.

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

If any detail in square brackets above is missing, ask me for it before you start.
