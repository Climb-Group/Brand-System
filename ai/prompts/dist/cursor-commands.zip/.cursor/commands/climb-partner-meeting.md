---
description: "Builds a one-page brief for a partner meeting: who they are, what they want, history with us and what to ask."
---

Prepare me for my meeting with [company] on [date].

Use my emails, chats and files about them, plus public information. Give me a one-page brief:
1. Who they are and what they sell, in three lines.
2. Our history with them and anything open.
3. What they probably want from ClimbUK and which audience they want to reach.
4. Three partnership ideas that fit, sold as meetings with the right people and moments on the day.
5. Five questions to ask.
6. The one next step to aim for.

Link sources and mark anything unconfirmed with [CHECK].

Brand rules: Write for ClimbUK in its brand voice: business with a party, not a party for business. Headline energy, doing not dreaming, curated not crowded, personal not generic. UK English. Hard rules: no emojis, no exclamation marks, no em or en dashes (use a hyphen-minus); never "Climb" on its own (write ClimbUK, ClimbGroup or the edition, such as Climb27); name no venue or city for an edition until ClimbUK has announced it; no attendance or audience numbers; no guarantees; never promise investor meetings, introductions or funding (say "find investors looking for real deal flow", not "meet investors"); no invented scarcity; no hedges such as TBC or coming soon; no vendor names; link text says where it goes. If you can load the climb-voice skill, follow it in full; otherwise read it at https://github.com/Climb-Group/Brand-System/blob/main/.agents/skills/climb-voice/SKILL.md

If any detail in square brackets above is missing, ask me for it before you start.
