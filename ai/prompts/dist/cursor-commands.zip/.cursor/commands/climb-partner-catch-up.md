---
description: "Summarises recent emails, chats, meetings and files with one partner company so you are up to speed in minutes."
---

Catch me up on [company]. Look at my emails, Teams chats, meetings and shared files from the last 30 days that mention them or their people.

1. Where things stand, in three sentences.
2. Decisions made and by whom, with dates.
3. Open questions and anything they are waiting on from us.
4. Upcoming meetings or deadlines.
5. The next thing I should do.

Link each point to its source. Work only from what you find; if something is unclear, say so instead of guessing.

If any detail in square brackets above is missing, ask me for it before you start.
